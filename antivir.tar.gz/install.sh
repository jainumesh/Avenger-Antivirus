#!/bin/bash
echo "Setting up DB"
sh antivirus-update.sh
sh add_syscall-address.sh
echo "Builing Source"
make |tee log
echo "Installing the Antivirus"
sudo rmmod -f avenger_protection
sudo insmod avenger_protection.ko
echo "Clean up the temporary mess"
make clean
