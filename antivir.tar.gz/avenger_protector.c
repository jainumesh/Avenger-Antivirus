/*
 * This is the template file used to build a system
 * specific kernel module.
*/
#include<linux/init.h>
#include<linux/module.h>
#include<linux/kernel.h>
#include<linux/errno.h>
#include<linux/types.h>
#include<linux/unistd.h>
#include<asm/current.h>
#include<linux/sched.h>
#include<linux/syscalls.h>
#include<linux/fcntl.h>
#include<linux/slab.h>
#include<linux/stat.h>
#include<linux/errno.h>
#include <linux/crypto.h>
#include <linux/err.h>
#include <linux/scatterlist.h>


#define SHA1_LENGTH     20
#define SYSCALL_TABLE_TEMPLATE
#define BLACKLIST_OFFSET 20
#define SIGNATURE_LENGTH 20
#define EVIRUS 1000
#define BUFSIZE 928
/*Check and set errno properly*/
#if 0
extern int * __error();
#define errno (* __error())
#endif
static int virus_found = 0;
unsigned long *sys_call_table = (unsigned long *) SYSCALL_TABLE;
char * whitelist = "/opt/AntivirusDB/whitelist";
char * blacklist = "/opt/AntivirusDB/blacklist";
unsigned char whitelistDB[1024];
unsigned char virusDB[1024];
asmlinkage int (*original_write)(unsigned int, const char __user *, size_t);
asmlinkage int (*original_mkdir)(const char __user *, mode_t);
asmlinkage long (*original_open)(const char __user *filename, int flags, umode_t mode);
asmlinkage long (*original_read) (unsigned int fd, char __user *buf, size_t count);
asmlinkage long (*original_close) (unsigned int fd);
asmlinkage long (*original_rename)(const char __user *oldname, const char __user *newname);
asmlinkage long (*original_chmod)(const char __user *filename, mode_t mode);
asmlinkage long (*original_sys_execve)(const char __user *filename,
                 const char __user *const __user *argv,
                 const char __user *const __user *envp);

static int loadDB(void){
	int fd1,n;
    mm_segment_t old_fs = get_fs();
    set_fs(KERNEL_DS);

    fd1 = (*original_open)(whitelist, O_RDONLY, 0);
    //printk(KERN_ALERT "Loading DB\n");
    if(fd1 <0){
      printk(KERN_ALERT "Whitelist file not available, please run antiviru_update.sh ");
      return -1;//return some bad value here
    }
    else{
    	if((n = (*original_read)(fd1, whitelistDB, 1024)) < 0){
      		printk(KERN_ALERT "Reading Whitelist failed\n");
      		return -1;//return some bad value here
   	 } 
    (*original_close)(fd1);

    fd1 = (*original_open)(blacklist, O_RDONLY, 0);

    if(fd1 <0){
      printk("blacklist file not available, please run antiviru_update.sh ");
      return -1;//return some bad value here
    }
    else{
    	if((n = (*original_read)(fd1, virusDB, 1024)) < 0){
      		printk("Reading blacklist failed\n");
      		return -1;//return some bad value here
   	 }
      }
    }	 
	(*original_close)(fd1);
	set_fs(old_fs);
	return 0;
    
}
static int calcsha(char * testfile)
{
    struct scatterlist sg;
    struct crypto_hash *tfm;
    struct hash_desc desc;
    unsigned char output[SHA1_LENGTH+1];
    //unsigned char buf[10];
    int n;
    int fd1;
    unsigned char cbuf[BUFSIZE];
    mm_segment_t old_fs = get_fs();
    set_fs(KERNEL_DS);
    //printk(KERN_ALERT "sha1: %s\n", __FUNCTION__);

    memset(cbuf, 0x00, BUFSIZE);
    memset(output, 0x00, SHA1_LENGTH+1);
    /*check for bad input filename*/
    if(!testfile){
        //printk("testfile is null, cant test\n");    
	return -1;
    }

    fd1 = (*original_open)(testfile, O_RDONLY, 0);
    if(fd1 <0){
      //printk("testfile opening failed, does my original_open work properly??");
      return -1;//return some bad value here
    }
    else{
    	if((n = (*original_read)(fd1, cbuf, BUFSIZE)) < 0){
      		//printk("very small file: %d bytes\n", n);
      		return -1;//return some bad value here
   	 } 
    }

    tfm = crypto_alloc_hash("sha1", 0, CRYPTO_ALG_ASYNC);

    desc.tfm = tfm;
    desc.flags = 0;

    sg_init_one(&sg, cbuf, BUFSIZE);
    crypto_hash_init(&desc);
#if 1
    crypto_hash_update(&desc, &sg, BUFSIZE);
    crypto_hash_final(&desc, output);
#endif
    output[SHA1_LENGTH] = '\0';

#if 1
    crypto_free_hash(tfm);
#endif
    set_fs(old_fs);

    //checking against whitelist here// should move the logic to another function later
    //printk(KERN_ALERT "SHA Calculated as [%s]",output);
#if 1
    if(strstr(whitelistDB,output)){
    //	printk("File is found to be a trusted program, Let go!!!\n");
    	return 1;    	
    }
#endif
    return 0;
}


static int scan_file(const char *filename1 ,const char * filename2)
{
  int fd2;
  //char buf[SIGNATURE_LENGTH+1];
  char signature[SIGNATURE_LENGTH+1];
  int n,i;
  mm_segment_t old_fs = get_fs();
  set_fs(KERNEL_DS);
  fd2 = (*original_open)(filename2, O_RDONLY, 0);
  if(fd2 <0){
	  return -1;//return some bad value here
  }
  else{
	if((n = (*original_read)(fd2, signature, BLACKLIST_OFFSET)) < 0){
		//printk("very small file: %d bytes\n", n);
		return -1;//return some bad value here
	}  
	for(i = 0;i<=SIGNATURE_LENGTH;i++)
		signature[i] = 0;
  	if((n = (*original_read)(fd2, signature, SIGNATURE_LENGTH)) < SIGNATURE_LENGTH){
		//printk("very small file: %d bytes\n", n+SIGNATURE_LENGTH);
		return -1;//return some bad value here
	}
	else{
		//(*original_read)(fd2, signature, 20)
		signature[n] = '\0';
		//printk("found signature as : [%s]\n", signature);
	}
  }	
  (*original_close)(fd2);
  set_fs(old_fs);

#if 0
  fd1 = (*original_open)(filename1, O_RDONLY, 0);
  if (fd1 >= 0) {
    //printk(KERN_DEFAULT  "Going to read a file in hijacked module \n");
    for( i =0;i<=SIGNATURE_LENGTH;i++)
	buf[i] = 0;
    while ((n =(*original_read)(fd1, buf, SIGNATURE_LENGTH))> 0){
	buf[n] = 0;
      //  printk(KERN_DEFAULT  "new entry from blacklist is [%s]\n", buf);
        if(!strcmp(buf,signature)){
      		printk(KERN_DEFAULT  "virus signature is [%s]\n", buf);
		return 1;
	}
#endif
  	if(strstr(virusDB,signature)){
	//	for(i = 0;i<20;i++)
		//	printk(KERN_ALERT "signature is %02X",signature[i]);
  		//printk(KERN_ALERT "virusDB:  [%s]\n",virusDB);
		//printk(KERN_ALERT "signature is [%s],\n", signature);
		return 1;
  	}
   return 0;	 
  }

asmlinkage int file_check(const char __user *pathname){
	int n=0;
	//printk(KERN_ALERT "\n MKDIR is hijacked now\n");
	//open_whitelist();
	if(strstr(pathname , "/var/run"))
	   return 0;
	n = calcsha(pathname);
        //printk(KERN_ALERT "%s 111returned %d",pathname , n);

	if(n != 1){
		n =  scan_file(blacklist,pathname);
		//printk(KERN_ALERT "%s returned %d",pathname , n);
		if(n == 1){
		// File is in Black List
		// Need to do some stuff here, currnetly just print
			char *newname = (char *)kmalloc(strlen(pathname) + 7, GFP_KERNEL);
			strncpy(newname,pathname, strlen(pathname));
			strncat(newname, ".virus", strlen(".virus"));
			printk(KERN_CRIT  "ATTENTION:: Virus Found on the system[%s]\n",pathname);
			//printk(KERN_CRIT  "Quarantine in Progress\n");
      virus_found = 1;
			(*original_chmod)(pathname,00000);
			(*original_rename)(pathname,newname);
      virus_found = 0;
			//printk(KERN_CRIT  "Virus [%s] Handled\n",pathname);
			//errno = EVIRUS;
			return -EVIRUS; // Returning a new special value to identify virus
		}
	}	
	return 0;
}
asmlinkage int new_mkdir(const char __user *pathname, mode_t mode){
                    
	return (*original_mkdir)(pathname , mode);	
}
#if 1
//check if hijacking write system call is needed??
asmlinkage int new_write(unsigned int fd, const char __user *buf, size_t count){	
	//Hijacked write function here
	return (*original_write)(fd, buf, count);
}

asmlinkage long new_sys_execve(const char __user *filename,
                 const char __user *const __user *argv,
                 const char __user *const __user *envp){
	//printk(KERN_ALERT "execve env [%s]\n", envp);
//	printk(KERN_ALERT "execve called  [%s] \n ",filename);
  if(filename && virus_found == 0)
    file_check(filename);                   
		
	//file_check(argv[1]);                
    return (*original_sys_execve)(filename,argv,envp);
}

asmlinkage long new_open(const char __user *filename, int flags, umode_t mode){
	if(filename && virus_found == 0)
		file_check(filename);
			              
	return (*original_open)(filename, flags, mode);

}

#endif

static int init_mod(void){
	printk(KERN_DEFAULT  "Syscall Table Address: %x\n", SYSCALL_TABLE);
	


	#if 1 // List of system calls we save for export
	original_open =  (void *)sys_call_table[__NR_open];
	original_sys_execve = (void *)sys_call_table[__NR_execve];
	original_write = (void *)sys_call_table[__NR_write];
	original_mkdir = (void *)sys_call_table[__NR_mkdir];	
	original_read = (void *)sys_call_table[__NR_read];
	original_close = (void *)sys_call_table[__NR_close];	
	original_rename = (void *)sys_call_table[__NR_rename];
	original_chmod =  (void *)sys_call_table[__NR_chmod];
	
	if(loadDB()) {
		printk("Loading DB Failed , antivirus wont function, please update/reinstall");
	        return 0;
        }
#endif	
	//Changing control bit to allow write	
	write_cr0 (read_cr0 () & (~ 0x10000));
#if 0// commenting write system call for now
	//write system call

	sys_call_table[__NR_write] = new_write;

	//original sys_execveat

	sys_call_table[__NR_execve] = new_sys_execve;

	//writning mkdir sys call
	sys_call_table[__NR_mkdir] = new_mkdir;
#endif	
	sys_call_table[__NR_open] = new_open;
	sys_call_table[__NR_execve] = new_sys_execve;

	//Changing control bit back
	write_cr0 (read_cr0 () | 0x10000);

	return 0;
}

static void exit_mod(void){
	//Cleanup

	write_cr0 (read_cr0 () & (~ 0x10000));
#if 1
	sys_call_table[__NR_mkdir] = original_mkdir;
	
	sys_call_table[__NR_write] = original_write;
	sys_call_table[__NR_execve] = original_sys_execve;
	sys_call_table[__NR_open] = original_open;
#endif	
	write_cr0 (read_cr0 () | 0x10000);
	printk(KERN_DEFAULT  "Module exited cleanly");
	return;
}
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Antivirus Module");
MODULE_AUTHOR("Avenger: ukjain@cs.stonybrook.edu");

module_init(init_mod);
module_exit(exit_mod);
