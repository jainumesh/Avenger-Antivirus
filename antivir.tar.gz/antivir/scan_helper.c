#include<stdio.h>
int main(int argc, char * argv[]){
	FILE*  fp;
	if (argv[1]){
		//printf("[%s]",argv[1]);

		fp = fopen(argv[1], "r");
		if(fp){
			//fprintf(stdout,"file opened [%s]",argv[1]);
			fclose(fp);	
		}
	}
	return 0;
}
