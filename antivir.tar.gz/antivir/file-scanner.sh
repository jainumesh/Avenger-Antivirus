RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\e[33m'
NC='\033[0m' # No Color
BLUE='\e[94m'
BLUE_BACKGROUND='\e[104m'

recurse(){
	
	test "$(ls -A "$1" 2>/dev/null)" || return

	for FILENAME in $(ls -d -1 $1/{.*,*})
	do
		if [ "$FILENAME" == "$1/." ] || [ "$FILENAME" == "$1/.." ]
		then
			continue
		fi

		if [ -d "$FILENAME" ]; then
			#printf "${BLUE}${FILENAME}${NC}\n"
			recurse $FILENAME
		else
			./scan_helper $FILENAME
			#printf "${YELLOW}${FILENAME}${NC}\n"
		fi
	done
}

recurse $1
