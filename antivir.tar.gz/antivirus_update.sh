#!/bin/bash

sudo rm -rf /opt/AntivirusDB/
git init
git clone https://github.com/jainumesh/AntiVirusDB /opt/AntivirusDB
chmod -R 550 /opt/AntivirusDB
